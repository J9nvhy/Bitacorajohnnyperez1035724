#Johnny Perez 1035724
#Proyecto No.2
#Tabla de matrices ocupando con una variacion de hashbrown(datos obtenidos mediante videos tutoriales del canal de calebcurry y neuralnine)
tabla = [0]* 8

for i in range (len(tabla)):
    tabla[i] = ["[    ]"] * 8
#Tabla De ajedrez de 8x8

def print_tabla(tabla):
    for i, fila in enumerate(tabla):
        print(8-i, end =": ")
        for j, col in enumerate(fila):
            print(col, end = " ")
        print ("\n")
    print(" " * 3 + "a" + "    " * 2 + "b" + "    " * 2 + "c" + "   "  * 2 + "d" + "   " * 2 + "e" + "   " * 2 + "f" + "   " * 2 + "g" + "   "  * 2 + "h")
 
print_tabla(tabla)

PiezasBlancas = {
    "PeonB" :    [(6,0), (6,1), (6,2), (6,3), (6,4), (6,5), (6,6), (6,7)],
    "CaballoB" : [(7,1), (7,6)],
    "AlfilB" :   [(7,2), (7,5)],
    "TorreB" :   [(7,0), (7,7)],
    "ReyB" :     [(7,3)],
    "ReinaB":    [(7,4)]
}

PiezasNegras = { 
    "PeonN":    [(1,0), (1,1),(1,2), (1,3), (1,4), (1,5), (1,6), (1,7)],
    "CaballoN": [(0,1), (0,6)],
    "AlfilN":   [(0,2), (0,5)],
    "TorreN":   [(0,0), (0,7)],
    "ReyN" :    [(0,3)],
    "ReinaN":   [(0,4)]
}   

columna= {
    "a": 0,
    "b": 1,
    "c": 2,
    "d": 3,
    "e": 4,
    "f": 5, 
    "g": 6,
    "h": 7,
}

def piezastab(tabla):
    for piezas, casillas in PiezasBlancas.items():
        for casilla in casillas:
            x,y = casilla[0], casilla[1]
            tabla[x][y] = piezas
    
    for piezas, casillas in PiezasNegras.items():
        for casilla in casillas:
            x,y = casilla[0], casilla[1]
            tabla[x][y] = piezas

piezastab(tabla)
print_tabla(tabla)

turno_uno = 1
while(True):
    print_tabla(tabla)
    print("")

    turno_jugador = ""
    if turno_uno % 2 == 1:
        turno_jugador = "Blancas"
    else:
        turno_jugador = " Negras"

    turno_uno += 1


    print(turno_jugador + " , es tu turno! ")
    print("")
    
    pricas= input( " , elige tu casilla( ejemplo, e6): ")
    ini_uno, ini_dos = pricas[0], pricas[1]
    ini_uno = columna[ini_uno]
    ini_dos = 8 - int(ini_dos)
    ini_uno, ini_dos = ini_dos, ini_uno

    segcas= input( " Eres negro, elige tu casilla (Ejemplo, e6): ")
    seg_uno, seg_dos = segcas[0], segcas[1]
    seg_uno = columna[seg_uno]
    seg_dos = 8 - int(seg_dos)
    seg_uno, seg_dos = seg_dos, seg_uno

    tablin = tabla[ini_uno][ini_dos]
    tabla[ ini_uno][ini_dos] = "  "
    tabla[ seg_uno][seg_dos] = tablin


   

           